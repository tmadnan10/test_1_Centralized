package org.qcri.sparkpca;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.apache.mahout.math.DenseMatrix;
import org.apache.mahout.math.Matrix;
import org.netlib.util.booleanW;


public class FileExists {
	static boolean[] done = null;
	static boolean checkDone(){
		for (int i = 0; i < done.length; i++) {
			if (!done[i]) {
				return true;
			}
		}
		return false;
	}
	
	public static void main(String[] args) throws InterruptedException, IOException {
		String myFileName = System.getProperty("fileIndex");
		File myFile = new File("W"+myFileName+".txt");
		Matrix m = new DenseMatrix(5, 5);
		PCAUtils.loadMatrixInDenseTextFormat(m, "W"+myFileName+".txt");
		boolean root = false;
		String parentID = null;
		String[] neighbours = null;
		File[] neigbourFiles = null;
		BufferedReader br = new BufferedReader(new FileReader("myInfo.txt"));
		String thisLine;
		thisLine = br.readLine();
		String [] splitted = thisLine.split("\\s+");
		if (splitted.length>1) {
			parentID = splitted[0];
		}
		else root = true;
		
		thisLine = br.readLine();
		splitted = thisLine.split("\\s+");
		//it has some child
		if (splitted.length > 1) {
			neighbours = new String[splitted.length-1];
			neigbourFiles = new File[splitted.length-1];
			for (int i = 0; i < splitted.length-1; i++) {
				neighbours[i] = splitted[i];
				neigbourFiles[i] = new File("dummy"+splitted[i]+"W"+myFileName);
			}
			
			done = new boolean[splitted.length-1];
			
			
			
			while(checkDone()){
				for (int i = 0; i < neigbourFiles.length; i++) {
					if (!done[i]) {
						File f = neigbourFiles[i];
						if(f.exists() && !f.isDirectory()) { 
						    System.out.println(f.getName()+" Exists");
						    Thread.sleep(4000);
						}
						else {
							System.out.println(f.getName()+" Not Exist");
							Process p;
							String commandString = "./test.sh "+neighbours[i]+" "+myFileName;
							p = Runtime.getRuntime().exec(commandString);
							p.waitFor();
							System.out.println("done comm");
							Matrix m1 = new DenseMatrix(5, 5);
							
							PCAUtils.loadMatrixInDenseTextFormat(m1, neighbours[i]+"W"+myFileName+".txt");
							for (int j = 0; j < m.rowSize(); j++) {
								for (int k = 0; k < m.columnSize(); k++){
									m.set(j, k, m.get(j, k)+m1.get(j, k));
								}
							}
							PCAUtils.printMatrixInDenseTextFormat(m, "W1.txt");
							done[i] = true;
							File file = new File(neighbours[i]+"W"+myFileName+".txt");
							file.delete();
							neigbourFiles[i].createNewFile();
						}
					}
				}
			}
		}
		//has no child i.e. a leaf node
		else {
			
		}
		
		//go and announce to parent;
		Process p;
		BufferedReader ID = new BufferedReader(new FileReader("ID.txt"));
		thisLine = ID.readLine();
		String dummyFileName = "dummy"+thisLine+"W"+myFileName;
		String commandString = "./notify.sh "+parentID+" "+dummyFileName;
		p = Runtime.getRuntime().exec(commandString);
		p.waitFor();
		System.out.println("Done Notifying");
	}
}
