/**
 * QCRI, sPCA LICENSE
 * sPCA is a scalable implementation of Principal Component Analysis (PCA) on of Spark and MapReduce
 *
 * Copyright (c) 2015, Qatar Foundation for Education, Science and Community Development (on
 * behalf of Qatar Computing Research Institute) having its principle place of business in Doha,
 * Qatar with the registered address P.O box 5825 Doha, Qatar (hereinafter referred to as "QCRI")
 *
*/
package org.qcri.sparkpca;

import java.io.File;
import java.io.PrintStream;
import java.io.Serializable;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import org.apache.hadoop.io.IntWritable;
import org.apache.log4j.Level;
import org.apache.mahout.math.DenseMatrix;
import org.apache.mahout.math.DenseVector;
import org.apache.mahout.math.Matrix;
import org.apache.mahout.math.Vector;
import org.apache.mahout.math.Vector.Element;
import org.apache.mahout.math.VectorWritable;
import org.apache.mahout.math.function.DoubleDoubleFunction;
import org.apache.mahout.math.function.Functions;
import org.apache.spark.Accumulator;
import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import org.apache.spark.api.java.function.Function;
import org.apache.spark.api.java.function.Function2;
import org.apache.spark.api.java.function.VoidFunction;
import org.apache.spark.broadcast.Broadcast;
import org.apache.spark.mllib.linalg.QRDecomposition;
import org.apache.spark.mllib.linalg.SparseVector;
import org.apache.spark.mllib.linalg.Vectors;
import org.apache.spark.mllib.linalg.distributed.RowMatrix;
import org.apache.spark.storage.StorageLevel;
import org.netlib.util.doubleW;
import org.netlib.util.intW;
import org.qcri.sparkpca.FileFormat.OutputFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import scala.Tuple2;

/**
 * This code provides an implementation of PPCA: Probabilistic Principal
 * Component Analysis based on the paper from Tipping and Bishop:
 * 
 * sPCA: PPCA on top of Spark
 * 
 * 
 * @author Tarek Elgamal
 * 
 */

public class TallnWide implements Serializable {
	private final static Logger log = LoggerFactory.getLogger(SparkPCA.class);// getLogger(SparkPCA.class);

	// variables for stats
	static String dataset = "amazon.txt1000000x1000.seq";
	static long startTime, endTime, totalTime;
	public static Stat stat = new Stat();

	public static void main(String[] args) {

		org.apache.log4j.Logger.getLogger("org").setLevel(Level.ERROR);
		org.apache.log4j.Logger.getLogger("akka").setLevel(Level.ERROR);

		// Parsing input arguments
		// String dataSet;
		final String inputPath;
		final String outputPath;
		final int nRows;
		final int nCols;
		final double avgCols;
		final int nPCs;
		final double tolerance;
		final int maxIter;
		final int maxMemory;
		try {
			inputPath = System.getProperty("i");
			if (inputPath == null)
				throw new IllegalArgumentException();
		} catch (Exception e) {
			printLogMessage("i");
			return;
		}
		try {
			outputPath = System.getProperty("o");
			if (outputPath == null)
				throw new IllegalArgumentException();
		} catch (Exception e) {
			printLogMessage("o");
			return;
		}

		try {
			dataset = System.getProperty("dataSet");
			if (dataset == null)
				throw new IllegalArgumentException();
		} catch (Exception e) {
			printLogMessage("dataSet");
			return;
		}

		try {
			nRows = Integer.parseInt(System.getProperty("rows"));
		} catch (Exception e) {
			printLogMessage("rows");
			return;
		}

		try {
			nCols = Integer.parseInt(System.getProperty("cols"));
		} catch (Exception e) {
			printLogMessage("cols");
			return;
		}

		try {
			avgCols = Integer.parseInt(System.getProperty("avgCols"));
		} catch (Exception e) {
			printLogMessage("avgCols");
			return;
		}

		try {
			tolerance = Double.parseDouble(System.getProperty("tolerance"));
		} catch (Exception e) {
			printLogMessage("toleance");
			return;
		}

		try {
			maxIter = Integer.parseInt(System.getProperty("maxIter"));
		} catch (Exception e) {
			printLogMessage("maxIter");
			return;
		}

		try {
			maxMemory = Integer.parseInt(System.getProperty("maxMemory"));
		} catch (Exception e) {
			printLogMessage("maxMemory");
			return;
		}

		try {

			if (Integer.parseInt(System.getProperty("pcs")) == nCols) {
				nPCs = nCols - 1;
				System.out
						.println("Number of princpal components cannot be equal to number of dimension, reducing by 1");
			} else
				nPCs = Integer.parseInt(System.getProperty("pcs"));
		} catch (Exception e) {
			printLogMessage("pcs");
			return;
		}

		// Setting Spark configuration parameters
		SparkConf conf = new SparkConf().setAppName("TallnWide").setMaster("local[*]");// TODO
																						// remove
																						// this
																						// part
																						// for
																						// building
		conf.set("spark.serializer", "org.apache.spark.serializer.KryoSerializer");
		conf.set("spark.kryoserializer.buffer.max", "128m");
		JavaSparkContext sc = new JavaSparkContext(conf);

		// log.info("Principal components computed successfully ");

		computePrincipalComponents(sc, inputPath, outputPath, nRows, nCols, avgCols, nPCs, maxIter, tolerance,
				maxMemory);


	}

	public static org.apache.spark.mllib.linalg.Matrix computePrincipalComponents(JavaSparkContext sc, String inputPath,
			String outputPath, final int nRows, final int nCols, final double avgCols, final int nPCs,
			final int maxIter, final double tolerance, final int maxMemory) {

		stat.appName = "TallnWide";
		stat.dataSet = dataset;
		stat.nRows = nRows;
		stat.nCols = nCols;
		stat.nPCs = nPCs;
		PCAUtils.printStatToFile(stat, outputPath);
		JavaPairRDD<IntWritable, VectorWritable> seqVectors = sc.sequenceFile(inputPath, IntWritable.class,
				VectorWritable.class);
		long s = seqVectors.count();

		JavaRDD<Tuple2<Integer, org.apache.spark.mllib.linalg.Vector>> vectors = seqVectors.map(
				new Function<Tuple2<IntWritable, VectorWritable>, Tuple2<Integer, org.apache.spark.mllib.linalg.Vector>>() {

					public Tuple2<Integer, org.apache.spark.mllib.linalg.Vector> call(
							Tuple2<IntWritable, VectorWritable> arg0) throws Exception {
						Integer index = arg0._1.get();

						org.apache.mahout.math.Vector mahoutVector = arg0._2.get();
						Iterator<Element> elements = mahoutVector.nonZeroes().iterator();
						ArrayList<Tuple2<Integer, Double>> tupleList = new ArrayList<Tuple2<Integer, Double>>();
						while (elements.hasNext()) {
							Element e = elements.next();
							if (e.index() >= nCols || e.get() == 0)
								continue;
							Tuple2<Integer, Double> tuple = new Tuple2<Integer, Double>(e.index(), e.get());
							tupleList.add(tuple);
						}
						Tuple2<Integer, org.apache.spark.mllib.linalg.Vector> sparkVector = new Tuple2<Integer, org.apache.spark.mllib.linalg.Vector>(
								index, Vectors.sparse(nCols, tupleList));

						return sparkVector;
					}
				}).persist(StorageLevel.MEMORY_ONLY_SER()); // TODO
															// change
															// later;

		seqVectors = null;
		System.gc ();
		System.runFinalization ();

		// 1. Mean Job : This job calculates the mean and span of the columns of
		// the input RDD<org.apache.spark.mllib.linalg.Vector>
		final Accumulator<double[]> matrixAccumY = sc.accumulator(new double[nCols], new VectorAccumulatorParam());
		final double[] internalSumY = new double[nCols];
		vectors.foreachPartition(new VoidFunction<Iterator<Tuple2<Integer, org.apache.spark.mllib.linalg.Vector>>>() {

			public void call(Iterator<Tuple2<Integer, org.apache.spark.mllib.linalg.Vector>> arg0) throws Exception {
				org.apache.spark.mllib.linalg.Vector yi;
				int[] indices = null;
				int i;
				while (arg0.hasNext()) {
					yi = arg0.next()._2;
					indices = ((SparseVector) yi).indices();
					for (i = 0; i < indices.length; i++) {
						internalSumY[indices[i]] += yi.apply(indices[i]);
					}
				}
				matrixAccumY.add(internalSumY);
			}

		});// End Mean Job


		// Get the sum of column Vector from the accumulator and divide each
		// element by the number of rows to get the mean
		// not best of practice to use non-final variable
		final Vector meanVector = new DenseVector(matrixAccumY.value()).divide(nRows);
		// matrixAccumY = null;
		final Broadcast<Vector> br_ym_mahout = sc.broadcast(meanVector);

		// TODO modify here for dynamically selecting appropriate partition for
		// W
		// dynamically set and assign range

		// hardcoded for now

		double sizeND = (s * avgCols * 8) / 1024 / 1024;
		double sizeNd = (1.0 * s * nPCs * 8) / 1024 / 1024;
		double maxM = Runtime.getRuntime().maxMemory() / 1024 / 1024;
		stat.maxMemory = (int) maxM;
		double memoryForW = maxM - sizeND - 2 * sizeNd;
		double sizeOfW = (4.0 * nCols * nPCs * 8) / 1024 / 1024;
		int partitionCount = (int) Math.ceil(sizeOfW / memoryForW);
		System.out.println("No of Partition of W: " + partitionCount);
		int nC = partitionCount + 1;
		stat.nPartitions = nC - 1;
		nC = maxMemory;
		int range[] = new int[nC];
		for (int i = 0; i < range.length; i++) {
			range[i] = i * nCols / (nC - 1);
		}

		System.out.println("Generating Initial W's");

		long IOTimeStart, IOTimeEnd, totalIOTime = 0;

		for (int i = 1; i < range.length; i++) {
			IOTimeStart = System.currentTimeMillis();
			int start = range[i - 1];
			int end = range[i];
			// System.out.println("Generating W"+i+" From "+start+" to "+end);
			Matrix matrix = new DenseMatrix(end - start, nPCs);
			matrix = PCAUtils.randomMatrix(end - start, nPCs);
			PCAUtils.printMatrixInDenseTextFormat(matrix, outputPath + File.separator + "W" + i);
			IOTimeEnd = System.currentTimeMillis();
			totalIOTime += IOTimeEnd - IOTimeStart;
		}
		System.out.println("Generation of Initial W's is complete \nStarting E-M Iterations");
		
		
		
		for (int round = 0; round < maxIter; round++) {
			System.out.println("count: "+vectors.count());
			System.out.println("\n\nStarting Round " + round);
			
			long heapSize1 = Runtime.getRuntime().totalMemory() / 1024 / 1024;
			long heapMaxSize1 = Runtime.getRuntime().maxMemory() / 1024 / 1024;
			long heapFreeSize1 = Runtime.getRuntime().freeMemory() / 1024 / 1024;
			System.out.println("HeapFreeSize: " + heapFreeSize1+"\nHeapAllocatedSize: " + (heapSize1-heapFreeSize1));
			startTime = System.currentTimeMillis();
			// M=W1'*W1;
			Matrix M = new DenseMatrix(nPCs, nPCs);

			JavaRDD<Tuple2<Integer, org.apache.spark.mllib.linalg.Vector>> X = null;
			// now for remaining portion of W
			JavaPairRDD<Tuple2<Integer, org.apache.spark.mllib.linalg.Vector>, Tuple2<Integer, org.apache.spark.mllib.linalg.Vector>> YnA = null;

			Vector xm_mahout = null;

			for (int i = 1; i < range.length; i++) {

				final int start = range[i - 1];
				final int end = range[i];

				final Matrix matrix = new DenseMatrix(end - start, nPCs);
				IOTimeStart = System.currentTimeMillis();
				PCAUtils.loadMatrixInDenseTextFormat(matrix, outputPath + File.separator + "W" + i);
				IOTimeEnd = System.currentTimeMillis();
				totalIOTime += IOTimeEnd - IOTimeStart;

				System.out.println("W" + i + " is Loaded From " + start + " to " + end);


				// M+=Wi'*Wi;
				M = M.plus(matrix.transpose().times(matrix));
				final Broadcast<Matrix> br_centralC = sc.broadcast(matrix);
				// System.out.println(matrix);
				// Xm = mu*Wi
				xm_mahout = new DenseVector(nPCs);
				xm_mahout = PCAUtils.denseVectorTimesMatrix(meanVector, matrix, start, end, xm_mahout);

				// Broadcast Xm because it will be used in several iterations.
				final Broadcast<Vector> br_xm_mahout = sc.broadcast(xm_mahout);

				if (i == 1) {
					// initializing the very first copy of X
					// if(round!=0) System.out.println(X.take(100).get(0)._2);

					X = vectors.map(
							new Function<Tuple2<Integer, org.apache.spark.mllib.linalg.Vector>, Tuple2<Integer, org.apache.spark.mllib.linalg.Vector>>() {

								@Override
								public Tuple2<Integer, org.apache.spark.mllib.linalg.Vector> call(
										Tuple2<Integer, org.apache.spark.mllib.linalg.Vector> v1) throws Exception {
									// TODO Auto-generated method stub
									// First Iteration

									org.apache.spark.mllib.linalg.Vector yi = v1._2;

									double resArrayX[] = new double[nPCs];

									// multiplying with W1
									Matrix matrix = br_centralC.value();
									int matrixCols = matrix.numCols();
									int[] indices;
									for (int col = 0; col < matrixCols; col++) {
										indices = ((SparseVector) yi).indices();
										int index = 0, i = 0;
										double value = 0;
										double dotRes = 0;
										for (i = 0; i < indices.length; i++) {
											index = indices[i];
											// checking the range here
											if (index > end) {
												break;
											}
											if (index >= start & index < end) {
												value = yi.apply(index);
												// index-initialStart will give
												// right row
												// index
												dotRes += matrix.getQuick(index - start, col) * value;
											}

										}
										// X=Y*Wi-mu*Wi
										resArrayX[col] = dotRes - br_xm_mahout.value().getQuick(col);
									}

									Tuple2<Integer, org.apache.spark.mllib.linalg.Vector> xi = new Tuple2<Integer, org.apache.spark.mllib.linalg.Vector>(
											v1._1, org.apache.spark.mllib.linalg.Vectors.dense(resArrayX));
									return xi;
								}

							});// TODO
								// check
								// if
								// improves
					// System.out.println(X.take(100).get(0)._2);
					int count = (int) X.count();
					System.out.println("Done Generating X for loop for i=" + i);


				} else {
					// zipping two RDDs for X=X+Y*Wi
					// System.out.println("Inside else before Zip "+X.count());
					YnA = vectors.zip(X);
					X = null;
					X = YnA.map(
							new Function<Tuple2<Tuple2<Integer, org.apache.spark.mllib.linalg.Vector>, Tuple2<Integer, org.apache.spark.mllib.linalg.Vector>>, Tuple2<Integer, org.apache.spark.mllib.linalg.Vector>>() {

								@Override
								public Tuple2<Integer, org.apache.spark.mllib.linalg.Vector> call(
										Tuple2<Tuple2<Integer, org.apache.spark.mllib.linalg.Vector>, Tuple2<Integer, org.apache.spark.mllib.linalg.Vector>> v1)
										throws Exception {
									// TODO Auto-generated method stub
									// TODO Auto-generated method stub
									// Get Y and X

									org.apache.spark.mllib.linalg.Vector yi = v1._1._2;
									org.apache.spark.mllib.linalg.Vector xi = v1._2._2;

									double resArrayX[] = new double[nPCs];

									// Y*Wi
									Matrix matrix = br_centralC.value();
									// if(v1._2._1.intValue()==0)System.out.println("inside----------\n"+matrix);
									int matrixCols = matrix.numCols();
									int[] indices;
									// range
									for (int col = 0; col < matrixCols; col++) {
										indices = ((SparseVector) yi).indices();
										int index = 0, i = 0;
										double value = 0;
										double dotRes = 0;
										for (i = 0; i < indices.length; i++) {
											index = indices[i];
											if (index > end) {
												break;
											}
											// multiply only those within range
											if (index >= start & index < end) {
												value = yi.apply(index);
												// Wi's row is not equal to
												// index but
												// index offset by start
												dotRes += matrix.getQuick(index - start, col) * value;
											}
										}
										resArrayX[col] = xi.apply(col) + dotRes - br_xm_mahout.value().getQuick(col);
									}
									// X=X+Y*Wi-mu*Wi

									// TODO check is zipping with same index
									// remove
									// later
									if (!v1._1._1.equals(v1._2._1))
										System.out.println(v1._1._1 + " " + v1._2._1 + "Index Mismatch");

									Tuple2<Integer, org.apache.spark.mllib.linalg.Vector> resXi = new Tuple2<Integer, org.apache.spark.mllib.linalg.Vector>(
											v1._2._1, org.apache.spark.mllib.linalg.Vectors.dense(resArrayX));

									return resXi;
								}

							});

					long count = X.count();
					YnA = null;
					System.gc();
					System.runFinalization();
					System.out.println("Done Generating X for i=" + i);


				}

			}

			YnA = vectors.zip(X);
			X = null;
			System.gc();
			System.runFinalization();
			System.out.println("After Map after last Zip " + YnA.count());


			Matrix centralYtX = null;
			Matrix centralXtX = null;
			Vector centralSumX = null;
			// Broadcast Xm because it will be used in several iterations.
			xm_mahout = new DenseVector(nPCs);
			for (int i = 0; i < xm_mahout.size(); i++) {
				xm_mahout.setQuick(i, 0);
			}
			// System.out.println(xm_mahout);
			final Broadcast<Vector> br_xm_mahout = sc.broadcast(xm_mahout);

			Matrix invM = PCAUtils.inv(M);
			// Matrix W=new DenseMatrix(nCols, nPCs);//Removed
			Matrix invXtX_central = null;
			// this stage starts after getting complete X
			double maxWnew = 0;
			double dw = 0;
			for (int i = 1; i < range.length; i++) {

				final int start = range[i - 1];
				final int end = range[i];

				System.out.println("Generating new W" + i+" from "+start+" to "+end);

				

				// calculate XtX in the first iteration
				if (i == 1) {
					
					final Accumulator<double[][]> matrixAccumXtx = sc.accumulator(new double[nPCs][nPCs],
							new MatrixAccumulatorParam());
					final Accumulator<double[]> matrixAccumX = sc.accumulator(new double[nPCs], new VectorAccumulatorParam());

					final double[][] resArrayXtX = new double[nPCs][nPCs];

					final double[][] internalSumXtX = new double[nPCs][nPCs];
					final double[] internalSumX = new double[nPCs];
					
					final Accumulator<double[][]> matrixAccumYtx = sc.accumulator(new double[end - start][nPCs],
							new MatrixAccumulatorParam());
					/*
					 * Initialize the output matrices and vectors once in order to
					 * avoid generating massive intermediate data in the workers
					 */
					final double[][] resArrayYtX = new double[end - start][nPCs];
					/*
					 * Used to sum the vectors in one partition.
					 */
					final double[][] internalSumYtX = new double[end - start][nPCs];
					
					YnA.foreachPartition(
							new VoidFunction<Iterator<Tuple2<Tuple2<Integer, org.apache.spark.mllib.linalg.Vector>, Tuple2<Integer, org.apache.spark.mllib.linalg.Vector>>>>() {

								@Override
								public void call(
										Iterator<Tuple2<Tuple2<Integer, org.apache.spark.mllib.linalg.Vector>, Tuple2<Integer, org.apache.spark.mllib.linalg.Vector>>> arg0)
										throws Exception {
									// TODO Auto-generated method stub
									org.apache.spark.mllib.linalg.Vector yi;
									org.apache.spark.mllib.linalg.Vector xi;
									Tuple2<Tuple2<Integer, org.apache.spark.mllib.linalg.Vector>, Tuple2<Integer, org.apache.spark.mllib.linalg.Vector>> input = null;
									while (arg0.hasNext()) {
										input = arg0.next();
										yi = input._1._2;
										xi = input._2._2;
										double resArrayX[] = xi.toArray();
										// get only the sparse indices
										int[] indices = ((SparseVector) yi).indices();

										PCAUtils.outerProductWithIndices(yi, br_ym_mahout.value(), resArrayX,
												br_xm_mahout.value(), resArrayYtX, indices, start, end);
										PCAUtils.outerProductArrayInput(resArrayX, br_xm_mahout.value(), resArrayX,
												br_xm_mahout.value(), resArrayXtX);
										int i, j, rowIndexYtX;

										// add the sparse indices only
										for (i = 0; i < indices.length; i++) {
											rowIndexYtX = indices[i];
											if (rowIndexYtX > end) {
												break;
											}
											if (rowIndexYtX >= start && rowIndexYtX < end) {
												for (j = 0; j < nPCs; j++) {
													internalSumYtX[rowIndexYtX - start][j] += resArrayYtX[rowIndexYtX
															- start][j];
													resArrayYtX[rowIndexYtX - start][j] = 0; // reset
																								// it
												}
											}

										}
										for (i = 0; i < nPCs; i++) {
											internalSumX[i] += resArrayX[i];
											for (j = 0; j < nPCs; j++) {
												internalSumXtX[i][j] += resArrayXtX[i][j];
												resArrayXtX[i][j] = 0; // reset
																		// it
											}

										}
									}
									matrixAccumX.add(internalSumX);
									matrixAccumXtx.add(internalSumXtX);
									matrixAccumYtx.add(internalSumYtX);
								}

							});// end X'X and Y'X Job
					/*
					 * Get the values of the accumulators.
					 */
					centralYtX = new DenseMatrix(matrixAccumYtx.value());
					centralXtX = new DenseMatrix(matrixAccumXtx.value());
					centralSumX = new DenseVector(matrixAccumX.value());

					centralXtX = (invM.transpose().times(centralXtX)).times(invM);

					// C = (Ye'*X) / SumXtX;
					invXtX_central = PCAUtils.inv(centralXtX);

				} else {
					
					heapSize1 = Runtime.getRuntime().totalMemory() / 1024 / 1024;
					heapMaxSize1 = Runtime.getRuntime().maxMemory() / 1024 / 1024;
					heapFreeSize1 = Runtime.getRuntime().freeMemory() / 1024 / 1024;
					System.out.println("HeapFreeSize: " + heapFreeSize1+"\nHeapAllocatedSize: " + (heapSize1-heapFreeSize1));
					final Accumulator<double[][]> matrixAccumYtx = sc.accumulator(new double[end - start][nPCs],
							new MatrixAccumulatorParam());
					/*
					 * Initialize the output matrices and vectors once in order to
					 * avoid generating massive intermediate data in the workers
					 */
					final double[][] resArrayYtX = new double[end - start][nPCs];
					/*
					 * Used to sum the vectors in one partition.
					 */
					final double[][] internalSumYtX = new double[end - start][nPCs];
					
					System.out.println("After Declaration");
					heapSize1 = Runtime.getRuntime().totalMemory() / 1024 / 1024;
					heapMaxSize1 = Runtime.getRuntime().maxMemory() / 1024 / 1024;
					heapFreeSize1 = Runtime.getRuntime().freeMemory() / 1024 / 1024;
					System.out.println("HeapFreeSize: " + heapFreeSize1+"\nHeapAllocatedSize: " + (heapSize1-heapFreeSize1));
					YnA.foreachPartition(
							new VoidFunction<Iterator<Tuple2<Tuple2<Integer, org.apache.spark.mllib.linalg.Vector>, Tuple2<Integer, org.apache.spark.mllib.linalg.Vector>>>>() {

								@Override
								public void call(
										Iterator<Tuple2<Tuple2<Integer, org.apache.spark.mllib.linalg.Vector>, Tuple2<Integer, org.apache.spark.mllib.linalg.Vector>>> arg0)
										throws Exception {
									// TODO Auto-generated method stub
									org.apache.spark.mllib.linalg.Vector yi;
									org.apache.spark.mllib.linalg.Vector xi;
									Tuple2<Tuple2<Integer, org.apache.spark.mllib.linalg.Vector>, Tuple2<Integer, org.apache.spark.mllib.linalg.Vector>> input = null;
									while (arg0.hasNext()) {
										input = arg0.next();
										yi = input._1._2;
										xi = input._2._2;
										double resArrayX[] = xi.toArray();
										// get only the sparse indices
										int[] indices = ((SparseVector) yi).indices();

										PCAUtils.outerProductWithIndices(yi, br_ym_mahout.value(), resArrayX,
												br_xm_mahout.value(), resArrayYtX, indices, start, end);
										int i, j, rowIndexYtX;

										// add the sparse indices only
										for (i = 0; i < indices.length; i++) {
											rowIndexYtX = indices[i];
											if (rowIndexYtX > end) {
												break;
											}
											if (rowIndexYtX >= start && rowIndexYtX < end) {
												for (j = 0; j < nPCs; j++) {
													internalSumYtX[rowIndexYtX - start][j] += resArrayYtX[rowIndexYtX
															- start][j];
													resArrayYtX[rowIndexYtX - start][j] = 0; // reset
																								// it
												}
											}

										}
									}
									matrixAccumYtx.add(internalSumYtX);
								}

							});// end X'X and Y'X Job
					System.out.println("Before Accumulator");
					centralYtX = new DenseMatrix(matrixAccumYtx.value());
					
				

				}

				/*
				 * Mi = (Yi-Ym)' x (Xi-Xm) = Yi' x (Xi-Xm) - Ym' x (Xi-Xm)
				 * 
				 * M = Sum(Mi) = Sum(Yi' x (Xi-Xm)) - Ym' x (Sum(Xi)-N*Xm)
				 * 
				 * The first part is done in the previous job and the second in
				 * the following method
				 */
				// System.out.println("Updating YtX");
				centralYtX = PCAUtils.updateXtXAndYtx(centralYtX, centralSumX, meanVector, xm_mahout, nRows, start,
						end);

				/*
				 * YtX=Y'*X*M-1
				 */
				centralYtX = centralYtX.times(invM);
				/*
				 * XtX=(M-1)'*X'*X*M-1
				 */

				final Matrix centralC = centralYtX.times(invXtX_central);

				// TODO
				// stop condition
				// dw = max(max(abs(W-Wnew) / (sqrt(eps)+max(max(abs(Wnew))))));

				for (int p = 0; p < end - start; p++) {
					for (int q = 0; q < nPCs; q++) {
						maxWnew = Math.max(Math.abs(centralC.getQuick(p, q)), maxWnew);
					}
				}
				final Matrix matrix = new DenseMatrix(end - start, nPCs);
				IOTimeStart = System.currentTimeMillis();
				PCAUtils.loadMatrixInDenseTextFormat(matrix, outputPath + File.separator + "W" + i);
				IOTimeEnd = System.currentTimeMillis();
				totalIOTime += IOTimeEnd - IOTimeStart;

				for (int p = 0; p < end - start; p++) {
					for (int q = 0; q < nPCs; q++) {
						dw = Math.max(Math.abs(matrix.getQuick(p, q) - centralC.getQuick(p, q)), dw);
					}
				}

				IOTimeStart = System.currentTimeMillis();
				PCAUtils.printMatrixInDenseTextFormat(centralC, outputPath + File.separator + "W" + i);
				IOTimeEnd = System.currentTimeMillis();
				totalIOTime += IOTimeEnd - IOTimeStart;
				System.out.println("New W" + i + " has beens saved");
				
				heapSize1 = Runtime.getRuntime().totalMemory() / 1024 / 1024;
				heapMaxSize1 = Runtime.getRuntime().maxMemory() / 1024 / 1024;
				heapFreeSize1 = Runtime.getRuntime().freeMemory() / 1024 / 1024;
				System.out.println("HeapFreeSize: " + heapFreeSize1+"\nHeapAllocatedSize: " + (heapSize1-heapFreeSize1));
				System.gc ();
				System.runFinalization ();
				
				heapSize1 = Runtime.getRuntime().totalMemory() / 1024 / 1024;
				heapMaxSize1 = Runtime.getRuntime().maxMemory() / 1024 / 1024;
				heapFreeSize1 = Runtime.getRuntime().freeMemory() / 1024 / 1024;
				System.out.println("\nHeapFreeSize: " + heapFreeSize1+"\nHeapAllocatedSize: " + (heapSize1-heapFreeSize1));
			}

			double sqrtEps = 2.2204e-16;
			dw /= (sqrtEps + maxWnew);
			stat.dwList.add(dw);
			if (dw <= tolerance) {
				endTime = System.currentTimeMillis();
				totalTime = endTime - startTime;
				stat.ppcaIterTime.add((double) totalTime / 1000.0);
				stat.totalRunTime += (double) totalTime / 1000.0;
				stat.nIter = round+1;
				for (int j = 0; j < stat.ppcaIterTime.size(); j++) {
					stat.avgppcaIterTime += stat.ppcaIterTime.get(j);
				}
				stat.avgppcaIterTime /= stat.ppcaIterTime.size();
				stat.IOTime = (double) totalIOTime / 1000.0;

				// save statistics
				PCAUtils.printStatToFile(stat, outputPath);
				break;
			}
			endTime = System.currentTimeMillis();
			totalTime = endTime - startTime;
			stat.ppcaIterTime.add((double) totalTime / 1000.0);
			stat.totalRunTime += (double) totalTime / 1000.0;

			startTime = System.currentTimeMillis();
			
			

		}
		return null;
	}

	private static void printLogMessage(String argName) {
		log.error("Missing arguments -D" + argName);
		log.info(
				"Usage: -Di=<path/to/input/matrix> -Do=<path/to/outputfolder> -Drows=<number of rows> -Dcols=<number of columns> -Dpcs=<number of principal components> [-DerrSampleRate=<Error sampling rate>] [-DmaxIter=<max iterations>] [-DoutFmt=<output format>] [-DComputeProjectedMatrix=<0/1 (compute projected matrix or not)>]");
	}
}