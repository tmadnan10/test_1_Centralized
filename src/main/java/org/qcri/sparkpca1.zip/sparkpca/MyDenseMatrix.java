package org.qcri.sparkpca;

import org.apache.mahout.math.DenseMatrix;
public class MyDenseMatrix extends DenseMatrix{

	public MyDenseMatrix(double[][] values) {
		super(values);
		// TODO Auto-generated constructor stub
	}
	
}
