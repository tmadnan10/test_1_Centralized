package org.qcri.sparkpca;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import org.apache.mahout.math.DenseMatrix;
import org.apache.mahout.math.Matrix;

public class Accumulate {
    
    static String WIndex, parentID, otherRootNode, myID;
    static int row,col;
    static boolean root, leaf;
    static String[] neighbours;
    static File[] neigbourFiles;
    
    public static void initialize() throws IOException {
        BufferedReader ID = new BufferedReader(new FileReader("ID"));
        myID = ID.readLine();
        ID.close();
        
        BufferedReader br = new BufferedReader(new FileReader("myInfo"));
        String thisLine;
        thisLine = br.readLine();
        String [] splitted = thisLine.split("\\s+");
        
        //not a root node as there is a parent
        if (splitted.length>1) {
            parentID = splitted[0];
        }
        
        //root node
        else root = true;
        
        System.out.println("ParentID: "+parentID);
        thisLine = br.readLine();
        splitted = thisLine.split("\\s+");
        
        if (splitted.length == 1) {
            leaf = true;
        }
        
        neighbours = new String[splitted.length-1];
        neigbourFiles = new File[splitted.length-1];
        
        for (int i = 0; i < splitted.length-1; i++) {
            neighbours[i] = splitted[i];
            neigbourFiles[i] = new File("dummy"+splitted[i]+"W"+WIndex);
        }
        
        done = new boolean[splitted.length-1];
        
        if(root){
	    thisLine = br.readLine();
	    splitted = thisLine.split("\\s+");
	    otherRootNode = splitted[1];
	    System.out.println("Other Root Node: "+otherRootNode);
	}        
        br.close();
        
    }
    
    public static void readSystemProperty(){
        System.out.println("getting initial information");
        WIndex = System.getProperty("WIndex");
        String r = System.getProperty("row");
        row = Integer.parseInt(r);
        String c = System.getProperty("column");
        col = Integer.parseInt(c);
    }
    
    static boolean[] done = null;
    static boolean checkDone(){
        for (int i = 0; i < done.length; i++) {
            if (!done[i]) {
                return true;
            }
        }
        System.out.println("Done");
        return false;
    }
    
    public static void runCommand(String commandString) throws IOException, InterruptedException{
        System.out.println(commandString);
        Process p = Runtime.getRuntime().exec(commandString);
        p.waitFor();
    }
    
    public static void sendWtoDestination(String source, String destination, String WIndex) throws IOException, InterruptedException{
        System.out.println("Sending "+source+"W"+WIndex+" to "+destination);
        String commandString = "./rsync_copy_W.sh "+source+" "+destination+" "+WIndex;
        //System.out.println(commandString);
        runCommand(commandString);
        System.out.println(source+"W"+WIndex+" has been sent to "+destination);
    }
    
    
    public static void notifyParent(String myID, String parentID, String WIndex) throws IOException, InterruptedException{
        System.out.println("Notifying to Parent");
        String dumWIndex = "dummy"+myID+"W"+WIndex;
        String commandString = "./notify.sh "+parentID+" "+dumWIndex;
        //System.out.println(commandString);
        runCommand(commandString);
        System.out.println("Done Notifying");
    }
    
    public static void notifyOtherRoot() throws IOException, InterruptedException {
        String commandString = "./notifyRoot.sh "+otherRootNode+" "+WIndex;
        //System.out.println(commandString);
        runCommand(commandString);
        String rootWIndexString = WIndex+"R";
        commandString = "cp W"+WIndex+" W"+WIndex+"R";
        runCommand(commandString);
        sendWtoDestination(myID,otherRootNode, rootWIndexString);
        commandString = "rm W"+WIndex+"R";
        runCommand(commandString);
    }
    
    public static void sendAccumulatedWtoNeighbours(String neighbour, String WIndex) throws IOException, InterruptedException{
        String commandString = "./sendAccumW.sh "+neighbour+" "+WIndex;
        //System.out.println(commandString);
        runCommand(commandString);
    }
    
    
    
    
    public static void main(String[] args) throws InterruptedException, IOException {
        
        readSystemProperty();
        
        
        System.out.println("load the W of this cluster");
        Matrix m = new DenseMatrix(row, col);
        PCAUtils.loadMatrixInDenseTextFormat(m, "W"+WIndex);
        
        initialize();
        
        
        //has no child i.e. a leaf node
        if (leaf) {
            System.out.println("No child... A Leaf Node\nSend the data to the parent node\nGive a notification by deleting dummy file");
            sendWtoDestination(myID,parentID, WIndex);
            notifyParent(myID, parentID, WIndex);
        }
        
        //it has some child
        //first accumulate from them then send to parent
        else {
            System.out.println("This node has some child nodes\nNeed to acculuate the child data while they are available\nChecking for rcvng any notification from any child node");
            
            while(checkDone()){
                for (int i = 0; i < neigbourFiles.length; i++) {
                    if (!done[i]) {
                        File f = neigbourFiles[i];
                        if(f.exists() && !f.isDirectory()) {
                            //file exists so look for next file
                            System.out.println(f.getName()+" Exists");
                            Thread.sleep(4000);
                        }
                        else {
                            System.out.println(f.getName()+" Not Exist");
                            //file doesnt exist so W from this child has been reached
                            Matrix m1 = new DenseMatrix(row, col);
                            PCAUtils.loadMatrixInDenseTextFormat(m1, neighbours[i]+"W"+WIndex);
                            m = m.plus(m1);
                            PCAUtils.printMatrixInDenseTextFormat(m, "W"+WIndex);
                            done[i] = true;
                            File file = new File(neighbours[i]+"W"+WIndex);
                            file.delete();
                            neigbourFiles[i].createNewFile();
                            Thread.sleep(3000);
                        }
                    }
                }
            }
            System.out.println("Done accum from all child nodes");
            if (!root) {
                sendWtoDestination(myID,parentID, WIndex);
                notifyParent(myID, parentID, WIndex);
            }
            else {
                System.out.println("This is a Root Node");
                
                notifyOtherRoot();
                
                
                
                //check if other root has already notified or not
                File rootCheckFile = new File("rootDone"+WIndex);
                while (!rootCheckFile.exists()) {
                    System.out.println("Other Root Not Done");
                    Thread.sleep(4000);
                }
                rootCheckFile.delete();
                //                //get the other root file
                //                commandString = "./rsync_copy_W.sh "+otherRootNode+" "+WIndex+"R";
                //                System.out.println(commandString);
                //                p = Runtime.getRuntime().exec(commandString);
                //                p.waitFor();
                
                
                Matrix m1 = new DenseMatrix(row, col);
                PCAUtils.loadMatrixInDenseTextFormat(m1, otherRootNode+"W"+WIndex+"R");
                m = m.plus(m1);
                
                PCAUtils.printMatrixInDenseTextFormat(m, "W"+WIndex);
                File file = new File(otherRootNode+"W"+WIndex+"R");
                file.delete();
                
                //done accumulation from all
                //create alldone file
                File currentCheckFile = new File("doneW"+WIndex);
                currentCheckFile.createNewFile();
            }
        }
        
        System.out.println("Done Accumulation from all");
        
        
        //redistribution part
        if (!leaf) {
            System.out.println("Starting Redistribution");
            File currentCheckFile = new File("doneW"+WIndex);
            while (!currentCheckFile.exists()) {
                System.out.println("done"+ WIndex +" File Not Generated");
                Thread.sleep(4000);
            }
            
            for (int i = 0; i < neigbourFiles.length; i++) {
                sendAccumulatedWtoNeighbours(neighbours[i],WIndex);
            }
            System.out.println("W"+WIndex+" Sent to all neighbour");
            
            
        }
    }
}

